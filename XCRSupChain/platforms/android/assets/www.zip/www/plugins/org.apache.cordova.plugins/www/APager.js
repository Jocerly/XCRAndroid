cordova.define("org.apache.cordova.plugins.APager", function(require, exports, module) {
var exec = require('cordova/exec');

module.exports = {

    skipto: function(str,object){
		exec(null,null,'APager','redirect',[str,object]);
	},
	back: function(data){
		exec(null,null,'APager','.goBack',[data]);
	},
	getdata: function(call){
		exec(call,function(){},'APager','getdata',{});
	},
	pop: function(url){
		exec(call,function(){},'APager','popPage',[url]);
	}
};


});
