cordova.define("cordova-plugin-ytlogicservice.YTLogicService", function(require, exports, module) {
var exec = require('cordova/exec');

var YTLogicService = {
	fetchCommonParams: function(onSuccess) {
		exec(onSuccess, null, "YTLogicService", "fetchCommonParams", []);
	},
	handleError: function(errorCode) {
		exec(null, null, "YTLogicService", "handleError", [errorCode]);
	}
};
module.exports = YTLogicService;

});
