cordova.define("org.apache.cordova.plugins.Toast.Toast", function(require, exports, module) {

var exec = require('cordova/exec');

module.exports = {

    toast: function(str){
		exec(function(){},function(){},'Toast','type_error',[str]);
	},
};

});
