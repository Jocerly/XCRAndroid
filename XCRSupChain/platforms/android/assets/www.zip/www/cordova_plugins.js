cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "id": "cordova-plugin-dialogs.notification",
        "file": "plugins/cordova-plugin-dialogs/www/notification.js",
        "pluginId": "cordova-plugin-dialogs",
        "merges": [
            "navigator.notification"
        ]
    },
    {
        "id": "cordova-plugin-dialogs.notification_android",
        "file": "plugins/cordova-plugin-dialogs/www/android/notification.js",
        "pluginId": "cordova-plugin-dialogs",
        "merges": [
            "navigator.notification"
        ]
    },
    {
        "id": "org.apache.cordova.plugins.Toast.Toast",
        "file": "plugins/org.apache.cordova.plugins.Toast/www/Toast.js",
        "pluginId": "org.apache.cordova.plugins.Toast",
        "clobbers": [
            "cordova.plugins.Toast"
        ]
    },
    {
        "id": "cordova-plugin-camera.Camera",
        "file": "plugins/cordova-plugin-camera/www/CameraConstants.js",
        "pluginId": "cordova-plugin-camera",
        "clobbers": [
            "Camera"
        ]
    },
    {
        "id": "cordova-plugin-camera.CameraPopoverOptions",
        "file": "plugins/cordova-plugin-camera/www/CameraPopoverOptions.js",
        "pluginId": "cordova-plugin-camera",
        "clobbers": [
            "CameraPopoverOptions"
        ]
    },
    {
        "id": "cordova-plugin-camera.camera",
        "file": "plugins/cordova-plugin-camera/www/Camera.js",
        "pluginId": "cordova-plugin-camera",
        "clobbers": [
            "navigator.camera"
        ]
    },
    {
        "id": "cordova-plugin-camera.CameraPopoverHandle",
        "file": "plugins/cordova-plugin-camera/www/CameraPopoverHandle.js",
        "pluginId": "cordova-plugin-camera",
        "clobbers": [
            "CameraPopoverHandle"
        ]
    },
    {
        "id": "cn-yatang-plugins.Pager.Pager",
        "file": "plugins/cn-yatang-plugins.Pager/www/Pager.js",
        "pluginId": "cn-yatang-plugins.Pager",
        "clobbers": [
            "cordova.plugins.Pager"
        ]
    },
    {
        "id": "org.apache.cordova.plugins.APager",
        "file": "plugins/org.apache.cordova.plugins/www/APager.js",
        "pluginId": "org.apache.cordova.plugins",
        "clobbers": [
            "cordova.plugins.APager"
        ]
    },
    {
        "id": "cordova-plugin-ytpay.YTPay",
        "file": "plugins/cordova-plugin-ytpay/www/YTPay.js",
        "pluginId": "cordova-plugin-ytpay",
        "clobbers": [
            "YTPay"
        ]
    },
    {
        "id": "cordova-plugin-navigation.YTNavigation",
        "file": "plugins/cordova-plugin-navigation/www/navigation.js",
        "pluginId": "cordova-plugin-navigation",
        "clobbers": [
            "YTNavigation"
        ]
    },
    {
        "id": "cordova-plugin-ytnetwork.YTNetwork",
        "file": "plugins/cordova-plugin-ytnetwork/www/ytnetwork.js",
        "pluginId": "cordova-plugin-ytnetwork",
        "clobbers": [
            "YTNetwork"
        ]
    },
    {
        "id": "cordova-plugin-ytlogicservice.YTLogicService",
        "file": "plugins/cordova-plugin-ytlogicservice/www/YTLogicService.js",
        "pluginId": "cordova-plugin-ytlogicservice",
        "clobbers": [
            "YTLogicService"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.3.2",
    "cordova-plugin-dialogs": "1.3.3",
    "org.apache.cordova.plugins.Toast": "0.0.1",
    "cordova-plugin-compat": "1.1.0",
    "cordova-plugin-camera": "2.4.1",
    "cn-yatang-plugins.Pager": "1.0.0",
    "org.apache.cordova.plugins": "1.0.0",
    "cordova-plugin-ytpay": "0.0.1",
    "cordova-plugin-navigation": "0.0.1",
    "cordova-plugin-ytnetwork": "0.0.1",
    "cordova-plugin-ytlogicservice": "0.0.1"
};
// BOTTOM OF METADATA
});